package ast;

public class AstStmt extends AstNode
{
}

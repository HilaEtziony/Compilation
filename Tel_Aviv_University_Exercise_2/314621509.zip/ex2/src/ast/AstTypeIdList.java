package ast;

public class AstTypeIdList extends AstDec
{
    public AstVarType head;
    public AstTypeIdList tail;

    public AstTypeIdList(AstVarType type, String identifier, AstTypeIdList rest_of_list){
        // TODO get line num
        serialNumber = AstNodeSerialNumber.getFresh();

        // TODO
        this.head = type;
        this.tail = rest_of_list;
    }
}

/*
accepts:

RESULT = new AstTypeIdList(t,i,l);
RESULT = new AstTypeIdList(t,i,null);
*/
// package ast;

// public abstract class AstCField extends AstDec
// {
// }

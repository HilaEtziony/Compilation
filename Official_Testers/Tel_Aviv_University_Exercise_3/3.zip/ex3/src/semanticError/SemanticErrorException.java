package semanticError;

public class SemanticErrorException extends RuntimeException {
    public SemanticErrorException(String message) {
        super(message);
    }
}
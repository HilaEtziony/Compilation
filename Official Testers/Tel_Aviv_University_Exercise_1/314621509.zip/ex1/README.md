# compilation_hw1_tests

steps to run the tester:
1. Download the testing and run_test.java and add them to your project 
2. run "Make"
3. if you got a problem during the test executing change the first line in run_test from   baseDir = System.getProperty("user.dir"); to BaseDir=[your path to ex1];
5. run "javac run_test.java"
6. run "java run_test"

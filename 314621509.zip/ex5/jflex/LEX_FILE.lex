/***************************/
/* FILE NAME: LEX_FILE.lex */
/***************************/

/*************/
/* USER CODE */
/*************/

import java_cup.runtime.*;

/******************************/
/* DOLLAR DOLLAR - DON'T TOUCH! */
/******************************/

%%

/************************************/
/* OPTIONS AND DECLARATIONS SECTION */
/************************************/

/*****************************************************/ 
/* Lexer is the name of the class JFlex will create. */
/* The code will be written to the file Lexer.java.  */
/*****************************************************/ 
%class Lexer

/********************************************************************/
/* The current line number can be accessed with the variable yyline */
/* and the current column number with the variable yycolumn.        */
/********************************************************************/
%line
%column

/*******************************************************************************/
/* Note that this has to be the EXACT same name of the class the CUP generates */
/*******************************************************************************/
%cupsym TokenNames

/******************************************************************/
/* CUP compatibility mode interfaces with a CUP generated parser. */
/******************************************************************/
%cup

/*********************/
/* LEXICAL STATES    */
/*********************/
/* 
 * Declare additional lexical states used for context-sensitive scanning.
 * These states allow the lexer to handle different token contexts separately.
 * YYINITIAL is the default start state.
 * INSIDE_QUOTES: Used when scanning inside string literals
 * COMMENT_TYPE_1: Used when scanning inside comment blocks (declare here!)
 */
%state COMMENT_TYPE_2

/****************/
/* DECLARATIONS */
/****************/
/*****************************************************************************/   
/* Code between %{ and %}, both of which must be at the beginning of a line, */
/* will be copied verbatim (letter to letter) into the Lexer class code.     */
/* Here you declare member variables and functions that are used inside the  */
/* scanner actions.                                                          */  
/*****************************************************************************/   
%{
	/*********************************************************************************/
	/* Create a new java_cup.runtime.Symbol with information about the current token */
	/*********************************************************************************/
	final int MAX_INT = 32767;

	private Symbol symbol(int type)               {return new Symbol(type, yyline, yycolumn);}
	private Symbol symbol(int type, Object value) {return new Symbol(type, yyline, yycolumn, value);}

	/*******************************************/
	/* Enable line number extraction from main */
	/*******************************************/
	public int getLine() { return yyline + 1; } 

	/**********************************************/
	/* Enable token position extraction from main */
	/**********************************************/
	public int getTokenStartPosition() { return yycolumn + 1; } 

	private Symbol isIntValid(String given_int){ 
		long value = Long.parseLong(given_int);
		
		if (value > MAX_INT) {
			throw new Error();
		}
		
		return symbol(TokenNames.INT, Integer.valueOf(yytext()));
	}

	final static String COMMENT_LEGAL = "()[]{}?!+-*;./ \t\f\r\n";
	private void checkLegalComment(String comment, int line){
		//System.out.println("Checking comment");
		//System.out.println(comment);
		//System.out.println(line);
		char c;
		for (int i = 0; i < comment.length(); i++) {
			c = comment.charAt(i);
            if (!Character.isLetterOrDigit(c) && COMMENT_LEGAL.indexOf(c) ==-1){
		//		System.out.println("Error in comment! " + c);
				throw new Error();
			}
        }
	}
%}

/***********************/
/* MACRO DECLARATIONS */
/***********************/
LineTerminator	= \r|\n|\r\n
WhiteSpace		= {LineTerminator} | [ \t\f]
KEYWORDS		= class | nil | array | while | int | void | extends | return | new | if | else | string
INTEGER			= 0 | [1-9][0-9]*
INT_W_LEADING_Z = 0[0-9]+
ID				= [a-zA-Z][a-zA-Z0-9]*
LETTERS			= [a-zA-Z]*
STRING_SEQ = "\"" [a-zA-z]* "\""
COMMENT_LEGAL_CHAR = [a-zA-Z0-9\(\)\[\]\{\}\?!+\-*/;. \t\f]
COMMENT_2_LEGAL_CHAR = {COMMENT_LEGAL_CHAR} | {LineTerminator}

/******************************/
/* DOLLAR DOLLAR - DON'T TOUCH! */
/******************************/

%%

/************************************************************/
/* LEXER matches regular expressions to actions (Java code) */
/************************************************************/

/**************************************************************/
/* YYINITIAL is the state at which the lexer begins scanning. */
/* So these regular expressions will only be matched if the   */
/* scanner is in the start state YYINITIAL.                   */
/**************************************************************/

<YYINITIAL> {
"//"[^\r\n]*(\r\n|\r|\n)	{ 
					String text = yytext();
					// Remove the "//" prefix and any line terminator suffix
					String comment = text.substring(2);
					// Remove trailing line terminators (handles \n, \r, or \r\n)
					comment = comment.replaceAll("[\r\n]+$", "");
					checkLegalComment(comment, yyline); 
}
"/*"				{ yybegin (COMMENT_TYPE_2) ; }

"("					{ return symbol(TokenNames.LPAREN); }
")"					{ return symbol(TokenNames.RPAREN); }
"["					{ return symbol(TokenNames.LBRACK); }
"]"					{ return symbol(TokenNames.RBRACK); }
"{"					{ return symbol(TokenNames.LBRACE); }
"}"					{ return symbol(TokenNames.RBRACE); }
"+"					{ return symbol(TokenNames.PLUS); }
"-"					{ return symbol(TokenNames.MINUS); }
"*"					{ return symbol(TokenNames.TIMES); }
"/"					{ return symbol(TokenNames.DIVIDE); }
","					{ return symbol(TokenNames.COMMA); }
"."					{ return symbol(TokenNames.DOT); }
";"					{ return symbol(TokenNames.SEMICOLON); }
"int"				{ return symbol(TokenNames.TYPE_INT); }
"string"			{ return symbol(TokenNames.TYPE_STRING); }
"void"				{ return symbol(TokenNames.TYPE_VOID); }
":="				{ return symbol(TokenNames.ASSIGN); }
"="					{ return symbol(TokenNames.EQ); }
"<"					{ return symbol(TokenNames.LT); }
">"					{ return symbol(TokenNames.GT); }
{STRING_SEQ}		{ return symbol(TokenNames.STRING, yytext()); }

"array"				{ return symbol(TokenNames.ARRAY); }
"class"				{ return symbol(TokenNames.CLASS); }
"return"			{ return symbol(TokenNames.RETURN); }
"while"				{ return symbol(TokenNames.WHILE); }
"if"				{ return symbol(TokenNames.IF); }
"else"				{ return symbol(TokenNames.ELSE); }
"new"				{ return symbol(TokenNames.NEW); }
"extends"			{ return symbol(TokenNames.EXTENDS); }
"nil"				{ return symbol(TokenNames.NIL); }

{INT_W_LEADING_Z} 	{ throw new Error(); } // It's before INTEGER otherwise wouldn't be cought
{INTEGER}			{ return isIntValid(yytext()); }
{ID}				{ return symbol(TokenNames.ID, String.valueOf(yytext())); }

{WhiteSpace}		{ }
<<EOF>>				{ return symbol(TokenNames.EOF); }
.                   { throw new Error(); } // Catch-all: Match any single character that is NOT a quote or a letter
}

<COMMENT_TYPE_2> {
"*/"					{ yybegin(YYINITIAL);}
{COMMENT_2_LEGAL_CHAR}	{}
. 						{ throw new Error(); }
<<EOF>>					{ throw new Error(); }
}
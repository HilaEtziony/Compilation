/***********/
/* PACKAGE */
/***********/
package ir;

/*******************/
/* GENERAL IMPORTS */
/*******************/

/*******************/
/* PROJECT IMPORTS */
/*******************/
import mips.MipsGenerator;
import temp.*;

public class IrCommandBinopDivIntegers extends IrCommandBinop
{

	public IrCommandBinopDivIntegers(Temp dst, Temp t1, Temp t2)
	{
		super(dst, t1, t2);
	}

	@Override
	public String toString()
	{
		return String.format("%s := %s / %s", dst, t1, t2);
	}

	@Override
	public void mipsMe() {
		MipsGenerator.getInstance().div(dst, t1, t2);
	}
}

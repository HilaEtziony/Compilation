package ir;

import java.util.*;
import mips.MipsGenerator;
import temp.Temp;

public class IrCommandStoreVTable extends IrCommand {
    public Temp dstObj;
    public String vtableName;

    public IrCommandStoreVTable(Temp dstObj, String vtableName) {
        this.dstObj = dstObj;
        this.vtableName = vtableName;
    }

    @Override
    public Set<Temp> use() { return dstObj != null ? Collections.singleton(dstObj) : Collections.emptySet(); }

    @Override
    public String toString() {
        return String.format("store_vtable(obj=%s, table=%s)", dstObj, vtableName);
    }

    @Override
    public void mipsMe() {
        MipsGenerator.getInstance().storeVTable(dstObj, vtableName);
    }
}

package ast;

import semanticError.SemanticErrorException;
import types.*;
import temp.*;
import ir.*;

/*
USAGE:
	| exp:e1 PLUS exp:e2											{: RESULT = new AstExpBinop(e1, e2, 0); 			:}
	| exp:e1 MINUS exp:e2											{: RESULT = new AstExpBinop(e1, e2, 1); 			:}
	| exp:e1 TIMES exp:e2											{: RESULT = new AstExpBinop(e1, e2, 2); 			:}
	| exp:e1 DIVIDE exp:e2											{: RESULT = new AstExpBinop(e1, e2, 3); 			:}
	| exp:e1 LT exp:e2												{: RESULT = new AstExpBinop(e1, e2, 4); 			:}
	| exp:e1 GT exp:e2												{: RESULT = new AstExpBinop(e1, e2, 5); 			:}
	| exp:e1 EQ exp:e2												{: RESULT = new AstExpBinop(e1, e2, 6); 			:}
*/

public class AstExpBinop extends AstExp
{
	int op;
	public AstExp left;
	public AstExp right;
	private Type leftType;
	
	/******************/
	/* CONSTRUCTOR(S) */
	/******************/
	public AstExpBinop(AstExp left, AstExp right, int op, int lineNumber)
	{
		/******************************/
		/* SET A UNIQUE SERIAL NUMBER */
		/******************************/
		serialNumber = AstNodeSerialNumber.getFresh();

		/***************************************/
		/* PRINT CORRESPONDING DERIVATION RULE */
		/***************************************/
		System.out.print("====================== exp -> exp BINOP exp\n");

		/*******************************/
		/* COPY INPUT DATA MEMBERS ... */
		/*******************************/
		this.lineNumber = lineNumber;
		this.left = left;
		this.right = right;
		this.op = op;
	}
	
	/*************************************************/
	/* The printing message for a binop exp AST node */
	/*************************************************/
	public void printMe()
	{
		String sop="";
		
		/*********************************/
		/* CONVERT OP to a printable sop */
		/*********************************/
		if (op == 0) {sop = "+";}
		if (op == 1) {sop = "-";}
		if (op == 3) {sop = "*";}
		if (op == 4) {sop = "/";}
		if (op == 4) {sop = "<";}
		if (op == 5) {sop = ">";}
		if (op == 6) {sop = "==";}

		/**********************************/
		/* AST NODE TYPE = AST BINOP EXP */
		/*********************************/
		System.out.print("AST NODE BINOP EXP\n");
		System.out.format("BINOP EXP(%s)\n",sop);

		/**************************************/
		/* RECURSIVELY PRINT left + right ... */
		/**************************************/
		if (left != null) left.printMe();
		if (right != null) right.printMe();

		/***************************************/
		/* PRINT Node to AST GRAPHVIZ DOT file */
		/***************************************/
		AstGraphviz.getInstance().logNode(
                serialNumber,
			String.format("BINOP(%s)",sop));
		
		/****************************************/
		/* PRINT Edges to AST GRAPHVIZ DOT file */
		/****************************************/
		if (left  != null) AstGraphviz.getInstance().logEdge(serialNumber,left.serialNumber);
		if (right != null) AstGraphviz.getInstance().logEdge(serialNumber,right.serialNumber);
	}

	public Type semantMe()
	{
		Type t1 = null;
		Type t2 = null;

		if (left  != null) t1 = left.semantMe();
		if (right != null) t2 = right.semantMe();

		// if class variables, extract their types
		if(t1 != null && t1 instanceof TypeClassVarDec) t1 = ((TypeClassVarDec)t1).t;
		if(t2 != null && t2 instanceof TypeClassVarDec) t2 = ((TypeClassVarDec)t2).t;

		this.leftType = t1;

		// + is allowed in TypeInt, TypeString
		// *, -, /, <, >, == are allowed in TypeInt only
		if ((t1 == TypeInt.getInstance()) && (t2 == TypeInt.getInstance()))
		{
			if (op == 0 /* + */ || op == 1 /* - */ || op == 2 /* * */)
			{
				return TypeInt.getInstance();
			}

			if (op == 3 /* / */)
			{
				// Division by zero check could be added here if right is a constant expression
				if (right.isConstant())
				{
					int rightValue = right.getConstantValue();
					if (rightValue == 0)
					{
						System.out.format(">> ERROR: Division by zero\n");
						throw new SemanticErrorException("ERROR(" + this.lineNumber + ")");
					}
				}

				return TypeInt.getInstance();
			}

			if (op == 4 /* < */ || op == 5 /* > */ || op == 6 /* == */)
			{
				return TypeInt.getInstance(); // L has 2 primitive types, but still we're splitting for login just in case that'll change
			}
		}

		if (t1 == TypeString.getInstance() && t2 == TypeString.getInstance())
		{
			if (op == 0 /* + */){
				return TypeString.getInstance();
			}

			if (op == 6 /* == */){
				return TypeInt.getInstance();
			}
		}

		if(t1 instanceof TypeClass || t2 instanceof TypeClass) {
			if(op != 6 /* == */) {
				System.out.format(">> ERROR: Invalid operation on class types\n");
				throw new SemanticErrorException("ERROR(" + this.lineNumber + ")");
			}
			if(t1 instanceof TypeClass && t2 instanceof TypeClass && (t1.isCompatible(t2) || t2.isCompatible(t1))) {
				return TypeInt.getInstance();
			}
			if(t1 == TypeNil.getInstance() || t2 == TypeNil.getInstance()) {
				if(op == 6 /* == */) {
					return TypeInt.getInstance();
				}
			}
		}
		if (t1 instanceof TypeArray || t2 instanceof TypeArray) {
			if (op != 6 /* == */) {
				System.out.format(">> ERROR: Invalid operation on array types\n");
				throw new SemanticErrorException("ERROR(" + this.lineNumber + ")");
			}
			if (t1 instanceof TypeArray && t2 instanceof TypeArray && (t1.isCompatible(t2) || t2.isCompatible(t1))) {
				return TypeInt.getInstance();
			}
			if (t1 == TypeNil.getInstance() || t2 == TypeNil.getInstance()) {
				if (op == 6 /* == */) {
					return TypeInt.getInstance();
				}
			}
		}

		throw new SemanticErrorException("ERROR(" + this.lineNumber + ")");
	}


	public Temp irMe()
	{
		Temp t1 = null;
		Temp t2 = null;
		Temp dst = TempFactory.getInstance().getFreshTemp();

		if (left  != null) t1 = left.irMe();
		if (right != null) t2 = right.irMe();

		if (op == 0) // PLUS
        {
			if (leftType == TypeString.getInstance()) {
				addIrCommand(new IrCommandStringConcat(dst, t1, t2));
			} else {
				addIrCommand(new IrCommandBinopAddIntegers(dst, t1, t2));
			}
        }
        else if (op == 1) // MINUS
        {
            addIrCommand(new IrCommandBinopSubIntegers(dst, t1, t2));
        }
        else if (op == 2) // TIMES (*)
        {
            addIrCommand(new IrCommandBinopMulIntegers(dst, t1, t2));
        }
        else if (op == 3) // DIVIDE (/)
        {
            addIrCommand(new IrCommandBinopDivIntegers(dst, t1, t2));
        }
        else if (op == 4) // LT (<)
        {
            addIrCommand(new IrCommandBinopLtIntegers(dst, t1, t2));
        }
        else if (op == 5) // GT (>)
        {
            addIrCommand(new IrCommandBinopGtIntegers(dst, t1, t2));
        }
        else if (op == 6) // EQ (==)
        {
			if (leftType == TypeString.getInstance()) {
                addIrCommand(new IrCommandStringEq(dst, t1, t2));
            } else {
                addIrCommand(new IrCommandBinopEqIntegers(dst, t1, t2));
            }
        }

		return dst;
	}

}